# Hey Beter
What this Chrome extension does is replace every letter B on a webpage to a "bemoji," so to speak. A "bemoji" is that red B emoji you see in all the memes.
