chrome.storage.local.get("HeyBeter", function(items) {
    beter = items["HeyBeter"];
    if (beter) {
        chrome.storage.local.set({'HeyBeter': false});
    } else {
        chrome.storage.local.set({'HeyBeter': true});
    }
});
